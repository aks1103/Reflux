<?php
echo time();
?>
